<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis readOnly="0" simplifyLocal="1" minScale="100000000" simplifyDrawingTol="1" hasScaleBasedVisibilityFlag="0" simplifyDrawingHints="1" labelsEnabled="0" symbologyReferenceScale="-1" maxScale="0" simplifyMaxScale="1" styleCategories="AllStyleCategories" version="3.22.12-Białowieża" simplifyAlgorithm="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal accumulate="0" endField="" durationField="" limitMode="0" enabled="0" durationUnit="min" startExpression="" endExpression="" fixedDuration="0" mode="0" startField="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <renderer-v2 symbollevels="0" referencescale="-1" forceraster="0" enableorderby="0" type="singleSymbol">
    <symbols>
      <symbol alpha="1" clip_to_extent="1" name="0" type="line" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" locked="0" class="ArrowLine">
          <Option type="Map">
            <Option name="arrow_start_width" value="0.15" type="QString"/>
            <Option name="arrow_start_width_unit" value="MM" type="QString"/>
            <Option name="arrow_start_width_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="arrow_type" value="0" type="QString"/>
            <Option name="arrow_width" value="0.15" type="QString"/>
            <Option name="arrow_width_unit" value="MM" type="QString"/>
            <Option name="arrow_width_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="head_length" value="1" type="QString"/>
            <Option name="head_length_unit" value="MM" type="QString"/>
            <Option name="head_length_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="head_thickness" value="1" type="QString"/>
            <Option name="head_thickness_unit" value="MM" type="QString"/>
            <Option name="head_thickness_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="head_type" value="0" type="QString"/>
            <Option name="is_curved" value="1" type="QString"/>
            <Option name="is_repeated" value="0" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="offset_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="ring_filter" value="0" type="QString"/>
          </Option>
          <prop v="0.15" k="arrow_start_width"/>
          <prop v="MM" k="arrow_start_width_unit"/>
          <prop v="3x:0,0,0,0,0,0" k="arrow_start_width_unit_scale"/>
          <prop v="0" k="arrow_type"/>
          <prop v="0.15" k="arrow_width"/>
          <prop v="MM" k="arrow_width_unit"/>
          <prop v="3x:0,0,0,0,0,0" k="arrow_width_unit_scale"/>
          <prop v="1" k="head_length"/>
          <prop v="MM" k="head_length_unit"/>
          <prop v="3x:0,0,0,0,0,0" k="head_length_unit_scale"/>
          <prop v="1" k="head_thickness"/>
          <prop v="MM" k="head_thickness_unit"/>
          <prop v="3x:0,0,0,0,0,0" k="head_thickness_unit_scale"/>
          <prop v="0" k="head_type"/>
          <prop v="1" k="is_curved"/>
          <prop v="0" k="is_repeated"/>
          <prop v="0" k="offset"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
          <prop v="0" k="ring_filter"/>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol alpha="1" clip_to_extent="1" name="@0@0" type="fill" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer pass="0" enabled="1" locked="0" class="SimpleFill">
              <Option type="Map">
                <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="0,0,0,255" type="QString"/>
                <Option name="outline_style" value="solid" type="QString"/>
                <Option name="outline_width" value="0.1" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="style" value="solid" type="QString"/>
              </Option>
              <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="bevel" k="joinstyle"/>
              <prop v="0,0" k="offset"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="0,0,0,255" k="outline_color"/>
              <prop v="solid" k="outline_style"/>
              <prop v="0.1" k="outline_width"/>
              <prop v="MM" k="outline_width_unit"/>
              <prop v="solid" k="style"/>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <customproperties>
    <Option type="Map">
      <Option name="embeddedWidgets/count" value="0" type="int"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer diagramType="Histogram" attributeLegend="1">
    <DiagramCategory backgroundColor="#ffffff" labelPlacementMethod="XHeight" minScaleDenominator="0" spacing="5" rotationOffset="270" penAlpha="255" opacity="1" minimumSize="0" penWidth="0" spacingUnit="MM" lineSizeType="MM" diagramOrientation="Up" backgroundAlpha="255" scaleBasedVisibility="0" lineSizeScale="3x:0,0,0,0,0,0" spacingUnitScale="3x:0,0,0,0,0,0" enabled="0" barWidth="5" sizeType="MM" maxScaleDenominator="1e+08" width="15" direction="0" sizeScale="3x:0,0,0,0,0,0" scaleDependency="Area" height="15" penColor="#000000" showAxis="1">
      <fontProperties description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style=""/>
      <attribute colorOpacity="1" label="" field="" color="#000000"/>
      <axisSymbol>
        <symbol alpha="1" clip_to_extent="1" name="" type="line" force_rhr="0">
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <layer pass="0" enabled="1" locked="0" class="SimpleLine">
            <Option type="Map">
              <Option name="align_dash_pattern" value="0" type="QString"/>
              <Option name="capstyle" value="square" type="QString"/>
              <Option name="customdash" value="5;2" type="QString"/>
              <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="customdash_unit" value="MM" type="QString"/>
              <Option name="dash_pattern_offset" value="0" type="QString"/>
              <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
              <Option name="draw_inside_polygon" value="0" type="QString"/>
              <Option name="joinstyle" value="bevel" type="QString"/>
              <Option name="line_color" value="35,35,35,255" type="QString"/>
              <Option name="line_style" value="solid" type="QString"/>
              <Option name="line_width" value="0.26" type="QString"/>
              <Option name="line_width_unit" value="MM" type="QString"/>
              <Option name="offset" value="0" type="QString"/>
              <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="offset_unit" value="MM" type="QString"/>
              <Option name="ring_filter" value="0" type="QString"/>
              <Option name="trim_distance_end" value="0" type="QString"/>
              <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="trim_distance_end_unit" value="MM" type="QString"/>
              <Option name="trim_distance_start" value="0" type="QString"/>
              <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="trim_distance_start_unit" value="MM" type="QString"/>
              <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
              <Option name="use_custom_dash" value="0" type="QString"/>
              <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            </Option>
            <prop v="0" k="align_dash_pattern"/>
            <prop v="square" k="capstyle"/>
            <prop v="5;2" k="customdash"/>
            <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
            <prop v="MM" k="customdash_unit"/>
            <prop v="0" k="dash_pattern_offset"/>
            <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
            <prop v="MM" k="dash_pattern_offset_unit"/>
            <prop v="0" k="draw_inside_polygon"/>
            <prop v="bevel" k="joinstyle"/>
            <prop v="35,35,35,255" k="line_color"/>
            <prop v="solid" k="line_style"/>
            <prop v="0.26" k="line_width"/>
            <prop v="MM" k="line_width_unit"/>
            <prop v="0" k="offset"/>
            <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
            <prop v="MM" k="offset_unit"/>
            <prop v="0" k="ring_filter"/>
            <prop v="0" k="trim_distance_end"/>
            <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
            <prop v="MM" k="trim_distance_end_unit"/>
            <prop v="0" k="trim_distance_start"/>
            <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
            <prop v="MM" k="trim_distance_start_unit"/>
            <prop v="0" k="tweak_dash_pattern_on_corners"/>
            <prop v="0" k="use_custom_dash"/>
            <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings obstacle="0" showAll="1" placement="2" dist="0" zIndex="0" priority="0" linePlacementFlags="18">
    <properties>
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties"/>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="None" name="TLINE40KID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="INPUT_SITE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="INKARSTID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="OUTPUTSITE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="OUTKARSTID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="TEST_DATE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="WEATHER">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="TRACERUSED">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="QUANTITY">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="OPERATOR">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="RESULT">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="GWFLOWRATE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="HYDRAUGRAD">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="DATASOURCE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="CATCHMENT">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="PEAK_CONC">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="OTHER_INFO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="FLOW_PATH">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="COUNTY">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LENGTH_M">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="DIRECTION">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" field="TLINE40KID" index="0"/>
    <alias name="" field="INPUT_SITE" index="1"/>
    <alias name="" field="INKARSTID" index="2"/>
    <alias name="" field="OUTPUTSITE" index="3"/>
    <alias name="" field="OUTKARSTID" index="4"/>
    <alias name="" field="TEST_DATE" index="5"/>
    <alias name="" field="WEATHER" index="6"/>
    <alias name="" field="TRACERUSED" index="7"/>
    <alias name="" field="QUANTITY" index="8"/>
    <alias name="" field="OPERATOR" index="9"/>
    <alias name="" field="RESULT" index="10"/>
    <alias name="" field="GWFLOWRATE" index="11"/>
    <alias name="" field="HYDRAUGRAD" index="12"/>
    <alias name="" field="DATASOURCE" index="13"/>
    <alias name="" field="CATCHMENT" index="14"/>
    <alias name="" field="PEAK_CONC" index="15"/>
    <alias name="" field="OTHER_INFO" index="16"/>
    <alias name="" field="FLOW_PATH" index="17"/>
    <alias name="" field="COUNTY" index="18"/>
    <alias name="" field="LENGTH_M" index="19"/>
    <alias name="" field="DIRECTION" index="20"/>
  </aliases>
  <defaults>
    <default expression="" field="TLINE40KID" applyOnUpdate="0"/>
    <default expression="" field="INPUT_SITE" applyOnUpdate="0"/>
    <default expression="" field="INKARSTID" applyOnUpdate="0"/>
    <default expression="" field="OUTPUTSITE" applyOnUpdate="0"/>
    <default expression="" field="OUTKARSTID" applyOnUpdate="0"/>
    <default expression="" field="TEST_DATE" applyOnUpdate="0"/>
    <default expression="" field="WEATHER" applyOnUpdate="0"/>
    <default expression="" field="TRACERUSED" applyOnUpdate="0"/>
    <default expression="" field="QUANTITY" applyOnUpdate="0"/>
    <default expression="" field="OPERATOR" applyOnUpdate="0"/>
    <default expression="" field="RESULT" applyOnUpdate="0"/>
    <default expression="" field="GWFLOWRATE" applyOnUpdate="0"/>
    <default expression="" field="HYDRAUGRAD" applyOnUpdate="0"/>
    <default expression="" field="DATASOURCE" applyOnUpdate="0"/>
    <default expression="" field="CATCHMENT" applyOnUpdate="0"/>
    <default expression="" field="PEAK_CONC" applyOnUpdate="0"/>
    <default expression="" field="OTHER_INFO" applyOnUpdate="0"/>
    <default expression="" field="FLOW_PATH" applyOnUpdate="0"/>
    <default expression="" field="COUNTY" applyOnUpdate="0"/>
    <default expression="" field="LENGTH_M" applyOnUpdate="0"/>
    <default expression="" field="DIRECTION" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="TLINE40KID" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="INPUT_SITE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="INKARSTID" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="OUTPUTSITE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="OUTKARSTID" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="TEST_DATE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="WEATHER" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="TRACERUSED" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="QUANTITY" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="OPERATOR" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="RESULT" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="GWFLOWRATE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="HYDRAUGRAD" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="DATASOURCE" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="CATCHMENT" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="PEAK_CONC" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="OTHER_INFO" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="FLOW_PATH" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="COUNTY" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="LENGTH_M" unique_strength="0" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" field="DIRECTION" unique_strength="0" notnull_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" field="TLINE40KID" exp=""/>
    <constraint desc="" field="INPUT_SITE" exp=""/>
    <constraint desc="" field="INKARSTID" exp=""/>
    <constraint desc="" field="OUTPUTSITE" exp=""/>
    <constraint desc="" field="OUTKARSTID" exp=""/>
    <constraint desc="" field="TEST_DATE" exp=""/>
    <constraint desc="" field="WEATHER" exp=""/>
    <constraint desc="" field="TRACERUSED" exp=""/>
    <constraint desc="" field="QUANTITY" exp=""/>
    <constraint desc="" field="OPERATOR" exp=""/>
    <constraint desc="" field="RESULT" exp=""/>
    <constraint desc="" field="GWFLOWRATE" exp=""/>
    <constraint desc="" field="HYDRAUGRAD" exp=""/>
    <constraint desc="" field="DATASOURCE" exp=""/>
    <constraint desc="" field="CATCHMENT" exp=""/>
    <constraint desc="" field="PEAK_CONC" exp=""/>
    <constraint desc="" field="OTHER_INFO" exp=""/>
    <constraint desc="" field="FLOW_PATH" exp=""/>
    <constraint desc="" field="COUNTY" exp=""/>
    <constraint desc="" field="LENGTH_M" exp=""/>
    <constraint desc="" field="DIRECTION" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortExpression="" sortOrder="0">
    <columns>
      <column width="-1" name="TLINE40KID" hidden="0" type="field"/>
      <column width="-1" name="INPUT_SITE" hidden="0" type="field"/>
      <column width="-1" name="INKARSTID" hidden="0" type="field"/>
      <column width="-1" name="OUTPUTSITE" hidden="0" type="field"/>
      <column width="-1" name="OUTKARSTID" hidden="0" type="field"/>
      <column width="-1" name="TEST_DATE" hidden="0" type="field"/>
      <column width="-1" name="WEATHER" hidden="0" type="field"/>
      <column width="-1" name="TRACERUSED" hidden="0" type="field"/>
      <column width="-1" name="QUANTITY" hidden="0" type="field"/>
      <column width="-1" name="OPERATOR" hidden="0" type="field"/>
      <column width="-1" name="RESULT" hidden="0" type="field"/>
      <column width="-1" name="GWFLOWRATE" hidden="0" type="field"/>
      <column width="-1" name="HYDRAUGRAD" hidden="0" type="field"/>
      <column width="-1" name="DATASOURCE" hidden="0" type="field"/>
      <column width="-1" name="CATCHMENT" hidden="0" type="field"/>
      <column width="-1" name="PEAK_CONC" hidden="0" type="field"/>
      <column width="-1" name="OTHER_INFO" hidden="0" type="field"/>
      <column width="-1" name="FLOW_PATH" hidden="0" type="field"/>
      <column width="-1" name="COUNTY" hidden="0" type="field"/>
      <column width="-1" name="LENGTH_M" hidden="0" type="field"/>
      <column width="-1" name="DIRECTION" hidden="0" type="field"/>
      <column width="-1" hidden="1" type="actions"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="CATCHMENT" editable="1"/>
    <field name="COUNTY" editable="1"/>
    <field name="DATASOURCE" editable="1"/>
    <field name="DIRECTION" editable="1"/>
    <field name="FLOW_PATH" editable="1"/>
    <field name="GWFLOWRATE" editable="1"/>
    <field name="HYDRAUGRAD" editable="1"/>
    <field name="INKARSTID" editable="1"/>
    <field name="INPUT_SITE" editable="1"/>
    <field name="LENGTH_M" editable="1"/>
    <field name="OPERATOR" editable="1"/>
    <field name="OTHER_INFO" editable="1"/>
    <field name="OUTKARSTID" editable="1"/>
    <field name="OUTPUTSITE" editable="1"/>
    <field name="PEAK_CONC" editable="1"/>
    <field name="QUANTITY" editable="1"/>
    <field name="RESULT" editable="1"/>
    <field name="TEST_DATE" editable="1"/>
    <field name="TLINE40KID" editable="1"/>
    <field name="TRACERUSED" editable="1"/>
    <field name="WEATHER" editable="1"/>
  </editable>
  <labelOnTop>
    <field name="CATCHMENT" labelOnTop="0"/>
    <field name="COUNTY" labelOnTop="0"/>
    <field name="DATASOURCE" labelOnTop="0"/>
    <field name="DIRECTION" labelOnTop="0"/>
    <field name="FLOW_PATH" labelOnTop="0"/>
    <field name="GWFLOWRATE" labelOnTop="0"/>
    <field name="HYDRAUGRAD" labelOnTop="0"/>
    <field name="INKARSTID" labelOnTop="0"/>
    <field name="INPUT_SITE" labelOnTop="0"/>
    <field name="LENGTH_M" labelOnTop="0"/>
    <field name="OPERATOR" labelOnTop="0"/>
    <field name="OTHER_INFO" labelOnTop="0"/>
    <field name="OUTKARSTID" labelOnTop="0"/>
    <field name="OUTPUTSITE" labelOnTop="0"/>
    <field name="PEAK_CONC" labelOnTop="0"/>
    <field name="QUANTITY" labelOnTop="0"/>
    <field name="RESULT" labelOnTop="0"/>
    <field name="TEST_DATE" labelOnTop="0"/>
    <field name="TLINE40KID" labelOnTop="0"/>
    <field name="TRACERUSED" labelOnTop="0"/>
    <field name="WEATHER" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field reuseLastValue="0" name="CATCHMENT"/>
    <field reuseLastValue="0" name="COUNTY"/>
    <field reuseLastValue="0" name="DATASOURCE"/>
    <field reuseLastValue="0" name="DIRECTION"/>
    <field reuseLastValue="0" name="FLOW_PATH"/>
    <field reuseLastValue="0" name="GWFLOWRATE"/>
    <field reuseLastValue="0" name="HYDRAUGRAD"/>
    <field reuseLastValue="0" name="INKARSTID"/>
    <field reuseLastValue="0" name="INPUT_SITE"/>
    <field reuseLastValue="0" name="LENGTH_M"/>
    <field reuseLastValue="0" name="OPERATOR"/>
    <field reuseLastValue="0" name="OTHER_INFO"/>
    <field reuseLastValue="0" name="OUTKARSTID"/>
    <field reuseLastValue="0" name="OUTPUTSITE"/>
    <field reuseLastValue="0" name="PEAK_CONC"/>
    <field reuseLastValue="0" name="QUANTITY"/>
    <field reuseLastValue="0" name="RESULT"/>
    <field reuseLastValue="0" name="TEST_DATE"/>
    <field reuseLastValue="0" name="TLINE40KID"/>
    <field reuseLastValue="0" name="TRACERUSED"/>
    <field reuseLastValue="0" name="WEATHER"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"TLINE40KID"</previewExpression>
  <mapTip></mapTip>
  <layerGeometryType>1</layerGeometryType>
</qgis>
